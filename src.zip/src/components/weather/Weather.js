// BUSINESS LOGIC
// DATA STRUCTURE AND EXCHANGE
import Axios from 'axios';
const KEY = '39a176e8bc91f23f7ec20a1fa3159409';
const URL = `http://api.openweathermap.org/data/2.5/weather?q=London,uk&appid=${KEY}`;
// spread operator!!!
class Day{
    constructor(date, icon, temp){
        this.date = date;
        this.icon = icon;
        this.temp = temp;
    }
}

class WeatherService{
    static getWeatherData(){ //<----------------static methods USE DIRECT FROM CLASS WITHOUT OBJECT
        Axios.get(URL)
             .then(response=>{
                console.log(response);
                let d = new Day("","", response.data.main.temp);
                console.log(d);
             });
        return new Day("01-01-2019","1.png", 20);
    }
}
export default WeatherService;

// usage

//let d = new Day(x,x,x);